KALKULATOR KAS - Android APK Project
Version 1.1.0

Project ini membungkus GitHub Pages KALKULATOR-KAS sebagai aplikasi Android WebView.
URL: https://ariyanto168-lgtm.github.io/KALKULATOR-KAS/

Build:
1. Buka folder ini di Android Studio.
2. Tunggu Gradle sync selesai.
3. Build > Build APK(s).
4. APK debug berada di app/build/outputs/apk/debug/app-debug.apk
